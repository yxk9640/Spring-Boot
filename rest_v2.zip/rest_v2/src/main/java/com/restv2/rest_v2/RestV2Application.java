package com.restv2.rest_v2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestV2Application {

	public static void main(String[] args) {
		SpringApplication.run(RestV2Application.class, args);
	}

}
